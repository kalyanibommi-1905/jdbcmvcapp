# JDBCMVCAPP following the standards of MVC like Controller layer,Service layer and DAO(persistence layer) and DTO as Student Object and FACTORY METHODS ALSO BEEN IMPLEMENTED
deveoped CRUD application using servlets,jsps,HTML,CSS and JDBC  through which the student can enter his name and his personal information
and can upload in database and correspondingly if the student want to know his/her information which is present in data base and can 
select the corresponding operation and asks for user id through which users/students information is displayed on the screen 
and if at all user/Client wants to modify their personal data which is present in database can select update in menu list and correspondinlgy
the student can update their information and finally if at all student wants to remove their accout they can select delete option and select their 
id and relatively tha data which is associated with that id will be deleted from database.
